# Mastermind v7 (Preparado para la ampliaci�n)
Mastermind v7 (Preparado para la ampliaci�n).

Fue un proyecto acad�mico editado por �ltima vez el 18-01-14.

El estado del proyecto es: Cerrado.

Est� escrito en C, y se ha publicado s�lo con el objetivo de mostrarlo p�blicamente.

Si te gusta el proyecto o quieres conocer m�s sobre el proyecto o sus desarrollaodres contacta a soryandroid@gmail.com





Todo el proyecto se encuentra bajo la licencia GNU General Public License v3.0
