/*
    Autores:
    �scar Valderrama Garc�a (soryandroid@gmail.com)
    �ngel Moreno Ontoria
*/

#pragma once // directiva de preprocesador que evita que el archivo de cabecera se incluya de nuevo
#define TAM 40

// Se declararn las funciones

void intro ();

void salir();
