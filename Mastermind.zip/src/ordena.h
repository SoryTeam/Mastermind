/*
    Autores:
    �scar Valderrama Garc�a (soryandroid@gmail.com)
    �ngel Moreno Ontoria
*/

#pragma once // directiva de preprocesador que evita que el archivo de cabecera se incluya de nuevo

// Se declaran las funciones

void ordenaID(sPartida*, int);

void ordenaPuntos(sPartida*, int);

void ordenaCombi(sPartida*, int);

void ordenaHora(sPartida*, int);
